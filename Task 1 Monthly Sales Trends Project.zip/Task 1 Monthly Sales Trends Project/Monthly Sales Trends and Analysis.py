import pandas as pd
df = pd.read_csv("Sample - Superstore.csv", encoding='ISO-8859-1')

df.isnull().sum()
df.dtypes
print(df[df['Sales'] < 0])
print(df[df['Quantity'] < 0])
df.duplicated().sum()

df['Order Date'] = pd.to_datetime(df['Order Date'])
df['Ship Date'] = pd.to_datetime(df['Ship Date'])

df['Year-Month'] = df['Order Date'].dt.to_period('M')
monthly_sales = df.groupby('Year-Month')['Sales'].sum()
print(monthly_sales)
monthly_sales.to_csv('monthly_sales.csv', index=True)
best_month = monthly_sales.idxmax()
worst_month = monthly_sales.idxmin()

print(f"🔹 Best Month: {best_month} with Sales: {monthly_sales.max():,.2f}")
print(f"🔸 Worst Month: {worst_month} with Sales: {monthly_sales.min():,.2f}")

import matplotlib.pyplot as plt

monthly_sales.plot(kind='line', figsize=(12, 6), marker='o', color='blue')
plt.title('Monthly Sales Trend')
plt.xlabel('Month')
plt.ylabel('Sales')
plt.grid(True)
plt.tight_layout()
plt.show()

region_sales = df.groupby('Region')['Sales'].sum()
region_sales.to_csv('region_sales.csv', index=True)

region_sales.plot(kind='bar', figsize=(8, 5), color='blue')
plt.title('Total Sales by Region')
plt.ylabel('Sales')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

top_products = df.groupby('Product Name')['Sales'].sum().sort_values(ascending=False).head(10)
top_products.to_csv('top_products.csv', index=True)

segment_sales = df.groupby('Segment')['Sales'].sum()
segment_sales.to_csv('segment_sales.csv', index=True)

category_sales = df.groupby(['Category', 'Sub-Category'])['Sales'].sum().unstack()
category_sales.to_csv('category_sales.csv', index=True)

