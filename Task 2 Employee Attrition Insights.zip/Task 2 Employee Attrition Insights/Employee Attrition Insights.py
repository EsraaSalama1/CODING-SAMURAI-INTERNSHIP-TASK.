import pandas as pd
import matplotlib.pyplot as plt
df = pd.read_csv("WA_Fn-UseC_-HR-Employee-Attrition.csv")

#Missing Values
print(df.isnull().sum())
#Duplicates 
print(df.duplicated().sum())
#Outliers
print(df['Age'].describe())
print(df['Attrition'].unique())
print(df['Department'].unique())

#Calculate the attrition rate
total_employees = len(df)
attrition_count = df[df['Attrition'] == 'Yes'].shape[0]
attrition_rate = (attrition_count / total_employees) * 100
print(f"Attrition Rate: {attrition_rate:.2f}%")

#attrition count by department
left_employees = df[df['Attrition'] == 'Yes']
attrition_by_department = left_employees['Department'].value_counts()
attrition_by_department.to_csv('attrition_by_department.csv', index=True)
plt.figure(figsize=(8, 5))
attrition_by_department.plot(kind='bar', color='coral')
plt.title('Attrition Count by Department')
plt.xlabel('Department')
plt.ylabel('Number of Employees Who Left')
plt.xticks(rotation=45)
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.tight_layout()
plt.show()

#the average age of employees who left
average_age = left_employees['Age'].mean()
print(f"Average Age of Employees Who Left: {average_age:.2f} years")

#Attrition by Gender
df[df['Attrition'] == 'Yes']['Gender'].value_counts(normalize=True) * 100

#Attrition by OverTime
df[df['Attrition'] == 'Yes']['OverTime'].value_counts()

#Attrition by Job Role
attrition_by_jobrole = left_employees['JobRole'].value_counts()
attrition_by_jobrole.to_csv('attrition_by_jobrole.csv', index=True)




